# from app import app, db, Village, Cantrip, Gainer, NonterminalDraw, Sifter, TerminalDraw, Duration

# # # Create the database tables
# with app.app_context():

#     card1 = Duration(cardName='Caravan')
#     card2 = Duration(cardName='Fishing_Village')
#     card3 = Duration(cardName='Haven')
#     card4 = Duration(cardName='Lighthouse')
#     card5 = Duration(cardName='Merchant_Ship')
#     card6 = Duration(cardName='Monkey')
#     card7 = Duration(cardName='Outpost')
#     card8 = Duration(cardName='Sailor')
#     card9 = Duration(cardName='Tactician')
#     card10 = Duration(cardName='Tide_Pools')
#     card11 = Duration(cardName='Wharf')
#     card12 = Duration(cardName='Blockade')
#     card13 = Duration(cardName='Sea_Witch')
#     card14 = Duration(cardName='Corsair')
#     card15 = Duration(cardName='Pirate')


#     db.session.add_all([card1, card2, card3, card4, card5, card6, card7, card8, card9, card10, card11, card12, card13, card14, card15])
#     db.session.commit()

#     # db.create_all()